
0. google cloud 설치
https://cloud.google.com/sdk/docs/install?hl=ko

1. google client library 설치
!pip install --upgrade google-cloud-texttospeech

2. 인증 설정
!gcloud init

!gcloud auth application-default login

!gcloud auth application-default set-quota-project glass-radar-438307-h0